----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 15.12.2024 18:19:53
-- Design Name: 
-- Module Name: hamming_encoder_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity hamming_encoder_tb is
end hamming_encoder_tb;

architecture Behavioral of hamming_encoder_tb is
    -- Signals for testing
    signal data_in : STD_LOGIC_VECTOR(3 downto 0);
    signal codeword_out : STD_LOGIC_VECTOR(6 downto 0);

    -- Clock period constant
    constant CLK_PERIOD : time := 10 ns;
begin
    -- Instantiate the encoder
    uut_encoder: entity work.hamming_encoder
        port map(
            data_in => data_in,
            codeword_out => codeword_out
        );

    -- Test process
    process
    begin
        -- Test case 1: Input 1010
        data_in <= "1010";
        wait for CLK_PERIOD;

        -- Verify encoded output
--        assert codeword_out = "1011010"
--        report "Test Case 1 Failed: Encoder output mismatch." severity error;
        wait for CLK_PERIOD;

        -- Test case 2: Input 1100
        data_in <= "1100";
        wait for CLK_PERIOD;

        -- Verify encoded output
--        assert codeword_out = "0110110"
--        report "Test Case 2 Failed: Encoder output mismatch." severity error;
        wait for CLK_PERIOD;

        -- Test case 3: Input 0001
        data_in <= "0001";
        wait for CLK_PERIOD;

        -- Verify encoded output
--        assert codeword_out = "1000101"
--        report "Test Case 3 Failed: Encoder output mismatch." severity error;
        wait for CLK_PERIOD;

        -- Test case 4: Input 1111
        data_in <= "1111";
        wait for CLK_PERIOD;

        -- Verify encoded output
--        assert codeword_out = "1111111"
--        report "Test Case 4 Failed: Encoder output mismatch." severity error;
        wait for CLK_PERIOD;

        -- End simulation
        report "All encoder test cases passed successfully." severity note;
        wait;
    end process;
end Behavioral;
