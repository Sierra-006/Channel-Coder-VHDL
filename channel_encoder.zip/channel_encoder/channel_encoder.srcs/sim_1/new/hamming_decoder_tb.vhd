library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity hamming_decoder_tb is
end hamming_decoder_tb;

architecture Behavioral of hamming_decoder_tb is
    -- Signals for testing
    signal codeword_in : STD_LOGIC_VECTOR(6 downto 0); -- Input: 7-bit received codeword
    signal data_out : STD_LOGIC_VECTOR(3 downto 0); -- Output: 4 corrected data bits
    signal error_pos : STD_LOGIC_VECTOR(2 downto 0); -- Error position as 3-bit binary value

    -- Internal signals for error injection
    signal corrupted_codeword : STD_LOGIC_VECTOR(6 downto 0);

    -- Clock period constant
    constant CLK_PERIOD : time := 8 ns;
begin
    -- Instantiate the decoder
    uut_decoder: entity work.hamming_decoder
        port map(
            codeword_in => codeword_in,
            data_out => data_out,
            error_pos => error_pos
        );

    -- Test process
    process
    begin
--    data_out <= "0000";
--    error_pos <= "000";
    corrupted_codeword <= "0000000";
    codeword_in <= "0000000";
            wait for CLK_PERIOD;

        -- Test case 1: Correct codeword (no error)
        codeword_in <= "1011010"; -- Encoded from data_in = "1010"
        wait for CLK_PERIOD*2;


        codeword_in <= "1001010"; -- Encoded from data_in = "1010"
        wait for CLK_PERIOD*2;
--            codeword_in <= "0000000";
--            wait for CLK_PERIOD*3;
        -- Test case 2: Single-bit error at position 4
        corrupted_codeword <= "1011010";
        corrupted_codeword(4) <= not corrupted_codeword(4); -- Flip bit at position 4
        codeword_in <= corrupted_codeword;
        wait for CLK_PERIOD;

--        -- Test case 3: Single-bit error at position 1
        corrupted_codeword <= "1011010";
        corrupted_codeword(1) <= not corrupted_codeword(1); -- Flip bit at position 1
        codeword_in <= corrupted_codeword;
        wait for CLK_PERIOD;

--        -- Test case 4: Correct codeword for data_in = 1100
--        codeword_in <= "0110110"; -- Encoded from data_in = "1100"
--        wait for CLK_PERIOD;

--        -- Test case 5: Single-bit error at position 7
--        corrupted_codeword <= "0110110";
--        corrupted_codeword(6) <= not corrupted_codeword(6); -- Flip bit at position 7
--        codeword_in <= corrupted_codeword;
--        wait for CLK_PERIOD;

        -- End simulation
        wait;
    end process;
end Behavioral;
