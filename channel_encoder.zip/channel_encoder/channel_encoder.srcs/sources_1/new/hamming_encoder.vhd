----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 15.12.2024 18:06:06
-- Design Name: 
-- Module Name: hamming_encoder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity hamming_encoder is
    Port (
        data_in : in STD_LOGIC_VECTOR(3 downto 0); -- Input: 4 data bits
        codeword_out : out STD_LOGIC_VECTOR(6 downto 0) -- Output: 7-bit codeword
    );
end hamming_encoder;

architecture Behavioral of hamming_encoder is
begin
    process(data_in)
        variable p1, p2, p3 : STD_LOGIC; -- Parity bits
    begin
        -- Calculate parity bits
        p1 := data_in(3) xor data_in(2) xor data_in(0);
        p2 := data_in(3) xor data_in(1) xor data_in(0);
        p3 := data_in(2) xor data_in(1) xor data_in(0);

        -- Construct the codeword
        codeword_out <= p1 & p2 & data_in(3) & p3 & data_in(2) & data_in(1) & data_in(0);
    end process;
end Behavioral;
