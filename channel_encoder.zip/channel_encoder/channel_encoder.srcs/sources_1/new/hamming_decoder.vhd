library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL; -- Include this library for `to_integer` and `unsigned` functions

entity hamming_decoder is
    Port (
        codeword_in : in STD_LOGIC_VECTOR(6 downto 0); -- Input: 7-bit received codeword
        data_out : out STD_LOGIC_VECTOR(3 downto 0); -- Output: 4 extracted data bits
        error_pos : out STD_LOGIC_VECTOR(2 downto 0) -- Error position as a 3-bit vector (binary)
    );
end hamming_decoder;

architecture Behavioral of hamming_decoder is
    signal p1, p2, p3 : STD_LOGIC; -- Recomputed parity bits
    signal s1, s2, s3 : STD_LOGIC; -- Syndrome bits
    signal syndrome : STD_LOGIC_VECTOR(2 downto 0); -- Syndrome vector
begin
    process(codeword_in)
    begin
        -- Recompute parity bits
        p1 <= codeword_in(4) xor codeword_in(2) xor codeword_in(0);
        p2 <= codeword_in(4) xor codeword_in(1) xor codeword_in(0);
        p3 <= codeword_in(2) xor codeword_in(1) xor codeword_in(0);

        -- Calculate syndrome vector
        s1 <= p1 xor codeword_in(6);
        s2 <= p2 xor codeword_in(5);
        s3 <= p3 xor codeword_in(3);
        syndrome <= s1 & s2 & s3;

        -- Assign syndrome vector directly to `error_pos`
        error_pos <= syndrome; -- Error position as a 3-bit binary value

        -- Extract data bits (as received, without correction)
        data_out <= codeword_in(4) & codeword_in(2) & codeword_in(1) & codeword_in(0);
    end process;
end Behavioral;
